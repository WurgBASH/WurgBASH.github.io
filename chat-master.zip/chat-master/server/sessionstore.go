/******************************************************************************
 *
 *  Description :
 *
 *  Management of long polling sessions
 *
 *****************************************************************************/

package main

import (
	"container/list"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"github.com/tinode/chat/pbx"
	"github.com/tinode/chat/server/store"
)

// SessionStore holds live sessions. Long polling sessions are stored in a linked list with
// most recent sessions on top. In addition all sessions are stored in a map indexed by session ID.
type SessionStore struct {
	rw sync.RWMutex

	// Support for long polling sessions: a list of sessions sorted by last access time.
	// Needed for cleaning abandoned sessions.
	lru      *list.List
	lifeTime time.Duration

	// All sessions indexed by session ID
	sessCache map[string]*Session
}

// Create creates a new session and adds it to store.
func (ss *SessionStore) Create(conn interface{}, sid string) *Session {
	var s Session

	s.sid = sid

	switch c := conn.(type) {
	case *websocket.Conn:
		s.proto = WEBSOCK
		s.ws = c
	case http.ResponseWriter:
		s.proto = LPOLL
		// no need to store c for long polling, it changes with every request
	case *ClusterNode:
		s.proto = CLUSTER
		s.clnode = c
		// case *GrpcNode:
	case pbx.Node_MessageLoopServer:
		s.proto = GRPC
		s.grpcnode = c
	default:
		s.proto = NONE
	}

	if s.proto != NONE {
		s.subs = make(map[string]*Subscription)
		s.send = make(chan interface{}, 256) // buffered
		s.stop = make(chan interface{}, 1)   // Buffered by 1 just to make it non-blocking
		s.detach = make(chan string, 64)     // buffered
	}

	s.lastTouched = time.Now()
	if s.sid == "" {
		s.sid = store.GetUidString()
	}

	ss.rw.Lock()
	ss.sessCache[s.sid] = &s

	if s.proto == LPOLL {
		// Only LP sessions need to be sorted by last active
		s.lpTracker = ss.lru.PushFront(&s)

		// Remove expired sessions
		expire := s.lastTouched.Add(-ss.lifeTime)
		for elem := ss.lru.Back(); elem != nil; elem = ss.lru.Back() {
			sess := elem.Value.(*Session)
			if sess.lastTouched.Before(expire) {
				ss.lru.Remove(elem)
				delete(ss.sessCache, sess.sid)
				sess.cleanUp()
			} else {
				break // don't need to traverse further
			}
		}
	}

	ss.rw.Unlock()

	return &s
}

// Get fetches a session from store by session ID.
func (ss *SessionStore) Get(sid string) *Session {
	ss.rw.Lock()
	defer ss.rw.Unlock()

	if sess := ss.sessCache[sid]; sess != nil {
		if sess.proto == LPOLL {
			ss.lru.MoveToFront(sess.lpTracker)
			sess.lastTouched = time.Now()
		}

		return sess
	}

	return nil
}

// Delete removes session from store.
func (ss *SessionStore) Delete(s *Session) {
	ss.rw.Lock()
	defer ss.rw.Unlock()

	delete(ss.sessCache, s.sid)

	if s.proto == LPOLL {
		ss.lru.Remove(s.lpTracker)
	}
}

// Shutdown terminates sessionStore. No need to clean up.
// Don't send to clustered sessions, their servers are not being shut down.
func (ss *SessionStore) Shutdown() {
	ss.rw.Lock()
	defer ss.rw.Unlock()

	shutdown := NoErrShutdown(time.Now().UTC().Round(time.Millisecond))
	for _, s := range ss.sessCache {
		if s.send != nil && s.proto != CLUSTER {
			s.send <- s.serialize(shutdown)
		}
	}

	log.Printf("SessionStore shut down, sessions terminated: %d", len(ss.sessCache))
}

// NewSessionStore initializes a session store.
func NewSessionStore(lifetime time.Duration) *SessionStore {
	store := &SessionStore{
		lru:      list.New(),
		lifeTime: lifetime,

		sessCache: make(map[string]*Session),
	}

	return store
}
