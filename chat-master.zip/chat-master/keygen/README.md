# keygen: API key generator

A command-line utility to generate an API key for [Tinode server](../server/)
